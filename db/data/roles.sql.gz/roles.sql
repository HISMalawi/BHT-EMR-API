-- ================================================================
-- Role Table Data
-- ================================================================
-- Insert all system roles into the role table
-- These roles can be assigned to users via the user_role table

INSERT INTO role (role, description, uuid) VALUES 
('Accompagnateur', 'Accompagnateur', UUID()),
('Accompagnateur Leader', 'Accompagnateur Leader', UUID()),
('Adults', 'Adults', UUID()),
('Anonymous', 'Anonymous', UUID()),
('Authenticated', 'Authenticated', UUID()),
('Clinician', 'Clinician', UUID()),
('Counselor', 'Counselor', UUID()),
('Data Assistant', 'Data Assistant', UUID()),
('Data Element Contributor', 'Data Element Contributor', UUID()),
('Data Manager', 'Data Manager', UUID()),
('Doctor', 'Doctor', UUID()),
('General Registration Clerk', 'General Registration Clerk', UUID()),
('Health Surveillance', 'Health Surveillance', UUID()),
('HMIS lab order', 'HMIS lab order', UUID()),
('HSA', 'HSA', UUID()),
('Informatics Manager', 'Informatics Manager', UUID()),
('Lab', 'Lab', UUID()),
('Medical Assistant', 'Medical Assistant', UUID()),
('Nurse', 'Nurse', UUID()),
('Paediatrics', 'Paediatrics', UUID()),
('Pharmacist', 'Pharmacist', UUID()),
('Program Manager', 'Program Manager', UUID()),
('Provider', 'Provider', UUID()),
('Registration Clerk', 'Registration Clerk', UUID()),
('Social Worker', 'Social Worker', UUID()),
('SPINE clinician', 'SPINE clinician', UUID()),
('Superuser', 'Superuser', UUID()),
('Global Superuser', 'Global Superuser', UUID()),
('Supervisor', 'Supervisor', UUID()),
('System Developer', 'System Developer', UUID()),
('Therapeutic Feeding Clerk', 'Therapeutic Feeding Clerk', UUID()),
('Vitals Clerk', 'Vitals Clerk', UUID()),
('Hospital Attendant', 'Hospital Attendant', UUID()),
('Student Clinician', 'Student Clinician', UUID())
ON DUPLICATE KEY UPDATE description=VALUES(description);
