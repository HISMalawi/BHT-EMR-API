-- MySQL dump 10.13  Distrib 9.2.0, for macos15.2 (arm64)
--
-- Host: localhost    Database: openmrs_anc
-- ------------------------------------------------------
-- Server version	9.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `concept_datatype`
--

DROP TABLE IF EXISTS `concept_datatype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `concept_datatype` (
  `concept_datatype_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `hl7_abbreviation` varchar(3) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`concept_datatype_id`),
  UNIQUE KEY `concept_datatype_uuid_index` (`uuid`) USING BTREE,
  KEY `concept_datatype_creator` (`creator`) USING BTREE,
  KEY `user_who_retired_concept_datatype` (`retired_by`) USING BTREE,
  KEY `concept_datatype_retired_status` (`retired`) USING BTREE,
  CONSTRAINT `concept_datatype_ibfk_1` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`),
  CONSTRAINT `concept_datatype_ibfk_2` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concept_datatype`
--

LOCK TABLES `concept_datatype` WRITE;
/*!40000 ALTER TABLE `concept_datatype` DISABLE KEYS */;
INSERT INTO `concept_datatype` VALUES (1,'Numeric','NM','Numeric value, including integer or float (e.g., creatinine, weight)',1,'2004-02-02 00:00:00',0,1,NULL,NULL,'8d4a4488-c2cc-11de-8d13-0010c6dffd0f'),(2,'Coded','CWE','Value determined by term dictionary lookup (i.e., term identifier)',1,'2004-02-02 00:00:00',0,1,NULL,NULL,'8d4a48b6-c2cc-11de-8d13-0010c6dffd0f'),(3,'Text','ST','Free text',1,'2004-02-02 00:00:00',0,1,NULL,NULL,'8d4a4ab4-c2cc-11de-8d13-0010c6dffd0f'),(4,'N/A','ZZ','Not associated with a datatype (e.g., term answers, sets)',1,'2004-02-02 00:00:00',0,1,NULL,NULL,'8d4a4c94-c2cc-11de-8d13-0010c6dffd0f'),(5,'Document','RP','Pointer to a binary or text-based document (e.g., clinical document, RTF, XML, EKG, image, etc.) stored in complex_obs table',1,'2004-04-15 00:00:00',0,1,NULL,NULL,'8d4a4e74-c2cc-11de-8d13-0010c6dffd0f'),(6,'Date','DT','Absolute date',1,'2004-07-22 00:00:00',0,1,NULL,NULL,'8d4a505e-c2cc-11de-8d13-0010c6dffd0f'),(7,'Time','TM','Absolute time of day',1,'2004-07-22 00:00:00',0,1,NULL,NULL,'8d4a591e-c2cc-11de-8d13-0010c6dffd0f'),(8,'Datetime','TS','Absolute date and time',1,'2004-07-22 02:00:00',0,NULL,NULL,NULL,'8d4a5af4-c2cc-11de-8d13-0010c6dffd0f'),(10,'Boolean','BIT','Boolean value (yes/no, true/false)',1,'2004-08-26 00:00:00',0,1,NULL,NULL,'8d4a5cca-c2cc-11de-8d13-0010c6dffd0f'),(11,'Rule','ZZ','Value derived from other data',1,'2006-09-11 13:22:00',0,1,NULL,NULL,'8d4a5e96-c2cc-11de-8d13-0010c6dffd0f'),(12,'Structured Numeric','SN','Complex numeric values possible (ie, <5, 1-10, etc.)',1,'2005-08-06 00:00:00',0,1,NULL,NULL,'8d4a606c-c2cc-11de-8d13-0010c6dffd0f'),(13,'Complex','ED','Complex value.  Analogous to HL7 Embedded Datatype',1,'2008-05-28 12:25:34',0,1,NULL,NULL,'8d4a6242-c2cc-11de-8d13-0010c6dffd0f');
/*!40000 ALTER TABLE `concept_datatype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concept_class`
--

DROP TABLE IF EXISTS `concept_class`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `concept_class` (
  `concept_class_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) DEFAULT NULL,
  `creator` int NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `retired` tinyint(1) NOT NULL DEFAULT '0',
  `retired_by` int DEFAULT NULL,
  `date_retired` datetime DEFAULT NULL,
  `retire_reason` varchar(255) DEFAULT NULL,
  `uuid` char(38) NOT NULL,
  `date_changed` datetime DEFAULT NULL,
  `changed_by` int DEFAULT NULL,
  PRIMARY KEY (`concept_class_id`),
  UNIQUE KEY `concept_class_uuid_index` (`uuid`) USING BTREE,
  KEY `concept_class_creator` (`creator`) USING BTREE,
  KEY `user_who_retired_concept_class` (`retired_by`) USING BTREE,
  KEY `concept_class_retired_status` (`retired`) USING BTREE,
  KEY `concept_class_changed_by` (`changed_by`),
  CONSTRAINT `concept_class_changed_by` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`),
  CONSTRAINT `concept_class_ibfk_1` FOREIGN KEY (`creator`) REFERENCES `users` (`user_id`),
  CONSTRAINT `concept_class_ibfk_2` FOREIGN KEY (`retired_by`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concept_class`
--

LOCK TABLES `concept_class` WRITE;
/*!40000 ALTER TABLE `concept_class` DISABLE KEYS */;
INSERT INTO `concept_class` VALUES (1,'Test','Acq. during patient encounter (vitals, labs, etc.)',1,'2004-02-02 00:00:00',0,1,NULL,NULL,'8d4907b2-c2cc-11de-8d13-0010c6dffd0f',NULL,1),(2,'Procedure','Describes a clinical procedure',1,'2004-03-02 00:00:00',0,NULL,NULL,NULL,'8d490bf4-c2cc-11de-8d13-0010c6dffd0f',NULL,NULL),(3,'Drug','Drug',1,'2004-02-02 00:00:00',0,1,NULL,NULL,'8d490dfc-c2cc-11de-8d13-0010c6dffd0f',NULL,1),(4,'Diagnosis','Conclusion drawn through findings',1,'2004-02-02 00:00:00',0,1,NULL,NULL,'8d4918b0-c2cc-11de-8d13-0010c6dffd0f',NULL,1),(5,'Finding','Practitioner observation/finding',1,'2004-03-02 00:00:00',0,1,NULL,NULL,'8d491a9a-c2cc-11de-8d13-0010c6dffd0f',NULL,1),(6,'Anatomy','Anatomic sites / descriptors',1,'2004-03-02 00:00:00',0,NULL,NULL,NULL,'8d491c7a-c2cc-11de-8d13-0010c6dffd0f',NULL,NULL),(7,'Question','Question (eg, patient history, SF36 items)',1,'2004-03-02 00:00:00',0,1,NULL,NULL,'8d491e50-c2cc-11de-8d13-0010c6dffd0f',NULL,1),(8,'LabSet','Term to describe laboratory sets',1,'2004-03-02 00:00:00',0,1,NULL,NULL,'8d492026-c2cc-11de-8d13-0010c6dffd0f',NULL,NULL),(9,'MedSet','Term to describe medication sets',1,'2004-02-02 00:00:00',0,NULL,NULL,NULL,'8d4923b4-c2cc-11de-8d13-0010c6dffd0f',NULL,NULL),(10,'ConvSet','Term to describe convenience sets',1,'2004-03-02 00:00:00',0,1,NULL,NULL,'8d492594-c2cc-11de-8d13-0010c6dffd0f',NULL,1),(11,'Misc','Terms which don\'t fit other categories',1,'2004-03-02 00:00:00',0,1,NULL,NULL,'8d492774-c2cc-11de-8d13-0010c6dffd0f',NULL,1),(12,'Symptom','Patient-reported observation',1,'2004-10-04 00:00:00',0,1,NULL,NULL,'8d492954-c2cc-11de-8d13-0010c6dffd0f',NULL,1),(13,'Symptom/Finding','Observation that can be reported from patient or found on exam',1,'2004-10-04 00:00:00',0,1,NULL,NULL,'8d492b2a-c2cc-11de-8d13-0010c6dffd0f',NULL,1),(14,'Specimen','Body or fluid specimen',1,'2004-12-02 00:00:00',0,1,NULL,NULL,'8d492d0a-c2cc-11de-8d13-0010c6dffd0f',NULL,1),(15,'Misc Order','Orderable items which aren\'t tests or drugs',1,'2005-02-17 00:00:00',0,NULL,NULL,NULL,'8d492ee0-c2cc-11de-8d13-0010c6dffd0f',NULL,NULL),(16,'Workflow','Workflow class',1,'2011-01-17 15:27:43',0,1,NULL,NULL,'1edca11a-768a-102f-83f4-12313b04a615',NULL,NULL),(17,'State','Workflow state',1,'2011-01-17 15:44:10',0,1,NULL,NULL,'1edca23c-768a-102f-83f4-12313b04a615',NULL,NULL),(18,'Program','Program concept',1,'2011-01-18 01:53:56',0,1,NULL,NULL,'1edca368-768a-102f-83f4-12313b04a615',NULL,NULL),(19,'Aggregate Measurement','A field used to capture an aggregate number used as a measurement.',1,'2012-06-11 16:01:24',0,1,NULL,NULL,'801e5b58-a14e-4a71-859d-23310b0f2f91',NULL,NULL),(20,'Indicator','An indicator calculated from certain measures.',1,'2012-06-11 16:01:45',0,1,NULL,NULL,'896d8b8c-603b-421f-959e-8d305cbeeb82',NULL,NULL),(21,'Health Care Monitoring Topics','Used for tagging content',1,'2012-06-25 13:23:33',0,1,NULL,NULL,'99ac2869-6615-4466-810b-8eb54544486a',NULL,NULL),(22,'Radiology/Imaging Procedure','A radiology or imaging test or procedure.',1,'2012-09-30 20:59:43',0,1,NULL,NULL,'8caa332c-efe4-4025-8b18-3398328e1323',NULL,NULL),(23,'Frequency','A concept used for capturing frequency information such as for medication ordering.',1,'2013-12-08 23:44:54',0,1,NULL,NULL,'8e071bfe-520c-44c0-a89b-538e9129b42a',NULL,1),(24,'Pharmacologic Drug Class','Class of medications based on pharmacologic properties as opposed to therapeutic properties',1,'2014-02-07 22:16:02',0,1,NULL,NULL,'b4535251-9183-4175-959e-9ee67dc71e78',NULL,1),(25,'Units of Measure','For prescribing and dispensing',1,'2014-02-13 21:31:25',0,1,NULL,NULL,'e30d8601-07f8-413a-9d11-cdfbb28196ec',NULL,1),(26,'Organism','Class of living organisms',1,'2014-05-16 01:36:38',0,1,NULL,NULL,'89a98300-062e-4003-8f6f-764ea23ab648',NULL,NULL),(27,'Drug form','Medication form for prescribing',1,'2014-05-16 13:21:42',0,1,NULL,NULL,'de359f23-2bfc-4e8d-96d8-25b7526d6070',NULL,NULL),(28,'Medical supply','Durable medical equipment and other supplies.',1,'2014-10-02 14:30:13',0,1,NULL,NULL,'0dcf23d4-3008-4d8e-b12c-4ec95d1cfd97',NULL,NULL),(29,'InteractSet','Set of drugs that interact with parent drug.',1,'2016-04-18 19:31:36',0,1,NULL,NULL,'e2c52f55-c7b4-49f7-9f82-1ffa2fe6023f',NULL,NULL),(33,'Test Department','Laboratory department grouping test categories (e.g. Hematology, Microbiology)',1,'2025-07-07 16:36:48',0,NULL,NULL,NULL,'d26b99b1-450b-4048-8835-6ad0d2c5fc90',NULL,NULL),(34,'Test Group','Grupos de testes laboratoriais ou clínicos',1,'2025-07-24 09:13:56',0,NULL,NULL,NULL,'8bb7875c-a395-4cf8-91c2-42a91adae795',NULL,NULL),(35,'Drug Regimen','Classe de conceito para Drug Regimen',1,'2025-10-06 07:26:43',0,NULL,NULL,NULL,'dbcf7b97-d6ab-4039-8dad-7368eb45c721',NULL,NULL),(36,'Clinical Service','Clinical Service',1,'2025-10-15 00:00:00',0,1,NULL,NULL,'df6528bd-a9ab-11f0-b8ec-e86a64ea1bc5',NULL,NULL),(37,'Clinical Service Instrument','Clinical Service Instrument/Program\nactivity',1,'2025-10-15 00:00:00',0,1,NULL,NULL,'dd5fa368-a9b2-11f0-b8ec-e86a64ea1bc5',NULL,NULL);
/*!40000 ALTER TABLE `concept_class` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-13 10:59:03
